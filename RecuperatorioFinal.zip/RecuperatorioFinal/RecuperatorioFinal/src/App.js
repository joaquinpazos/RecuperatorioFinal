import React, {Component} from 'react';
import { StyleSheet,
   Text,
   View 
} from 'react-native';

import {styles} from './styles/styles'
import  {Screen_1} from './Screens/Screen_1';
import  {Screen_2} from './Screens/Screen_2';
import {Home} from './Screens/Home'
import 'react-native-gesture-handler';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createDrawerNavigator } from '@react-navigation/drawer';

const Drawer = createDrawerNavigator();

class App extends Component{
   
   render(){
      return(
         <NavigationContainer>
          <Drawer.Navigator  initialRouteName="Home">
            <Drawer.Screen name="Home" component= {Home}options={{title: 'Home'}}/>
            <Drawer.Screen name="Screen 1" component= {Screen_1}options={{title: 'Tarjetas'}}/>
            <Drawer.Screen name="Screen 2" component= {Screen_2}options={{title: 'Tarjetas Guardadas'}}/>
          </Drawer.Navigator>
        </NavigationContainer>
      )
   }
}

export default App;