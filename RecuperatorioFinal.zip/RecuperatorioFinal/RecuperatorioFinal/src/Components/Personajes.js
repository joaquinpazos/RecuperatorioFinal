import React, {Component} from 'react';
import {styles} from '../styles/styles';
import { 
  View,
  Text,
  Image,
} from "react-native";

export default class Personajes extends Component{

    constructor(){
        super();
        this.state={

        }
    }

    render(){
        return(
        <View>
            <Image source={{uri: this.props.results.image}}/>
            <View><Text>{this.props.results.name}</Text></View>
            <View><Text>{this.props.results.status}</Text></View>
            <View><Text>{this.props.results.species}</Text></View>
        </View>
        )
    }
}
