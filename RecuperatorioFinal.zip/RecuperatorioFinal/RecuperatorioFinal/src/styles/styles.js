import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    cointainer:{
        justifyContent: 'center',
        alignItems: 'center',
        flex: 1,
    },
    caja:{
        justifyContent: 'center', 
        alignItems: 'center'
    },
    texto:{
        fontSize: 15,
        color: 'red',
        marginTop: 30,
        fontSize: 30,
    },
    boton:{
        width: 100,
        height: 90,
        backgroundColor: 'orange',
        marginTop:80,
        borderRadius: 20,
        alignItems: 'center',
        justifyContent: 'center',
    }
})