import React, {Component} from 'react';
import {
  Text, 
  View,
  Button,
  TouchableOpacity,
  FlatList,
} from 'react-native';
import {styles} from '../styles/styles'
import { TraigoData } from '../api/traigoUser';
import Personajes from '../Components/Personajes';



export class Screen_2 extends Component{
   constructor(props){
       super(props);
       this.state={
           users:[],
           showModal: false,
       }
   }
   
keyExtractor = (item, idx) => idx.toString();
renderItem= ({item}) => {
    return(
        <View>
            <TouchableOpacity onPress={()=> this.showModal(item)}>
                <Personajes
                nombre={item.results.name}
                especie={item.results.species}
                status = {item.results.status} 
                imagen = {item.results.image}
                />
            </TouchableOpacity>
        </View>
    )
}

    render(){
        return(
            <View>
                <View style={styles.caja}>
                    <TouchableOpacity onPress={()=> {TraigoData('userData').then(users=>{
                        this.setState({users:users})
                    })}}>
                        <Text style={styles.texto}>
                            Mostrar Contactos
                        </Text>
                    </TouchableOpacity>
                    {this.state.activity
                    ?<React.Fragment>
                    <ActivityIndicator
                        color="red"
                        size={60}
                            />
                    </React.Fragment>
        
                    :<FlatList
                    data= {this.state.users}
                    keyExtractor={this.keyExtractor}
                    renderItem= {this.renderItem}
                    ItemSeparatorComponent = {this.separator}
                    numColumns= {1}
                    />
                    }
                </View>
            </View>
        )
    }
}