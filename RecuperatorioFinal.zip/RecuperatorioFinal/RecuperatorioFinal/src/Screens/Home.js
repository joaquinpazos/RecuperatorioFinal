import React, {Component} from 'react';
import {
  Text, 
  View,
  Button,
  TouchableOpacity,
} from 'react-native';
import {styles} from '../styles/styles'

export class Home extends Component{
    render(){
        return(
            <View style={styles.container}>
                <View style={styles.caja}>
                    <TouchableOpacity style={styles.boton}>
                        <Button title="Tarjetas" onPress={() => this.props.navigation.navigate('Screen 1')}/>
                    </TouchableOpacity>
                </View>
                <View style={styles.caja}>
                    <TouchableOpacity style={styles.boton}> 
                        <Button title="Tarjetas Favoritas"  onPress={() => this.props.navigation.navigate('Screen 2')}/>
                    </TouchableOpacity>
                </View>
            </View>
        )
    }
}