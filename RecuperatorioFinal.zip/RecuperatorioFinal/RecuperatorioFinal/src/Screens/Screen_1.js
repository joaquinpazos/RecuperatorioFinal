import React, {Component} from 'react';
import { AsyncStorage } from '@react-native-async-storage/async-storage';
import {
  Text, 
  View,
  Button,
  TouchableOpacity,
  ScrollView,
  Alert,
} from 'react-native';
import {styles} from '../styles/styles'
// importo funciones api
import { GuardoData } from '../api/guardoApi';
import { TraigoData } from '../api/traigoUser';
import { GetData } from '../api/generoUser';
import Personajes from '../Components/Personajes';
import { FlatList } from 'react-native-gesture-handler';

export class Screen_1 extends Component{
    constructor(props){
        super(props);
        this.state={
            users: [],
            activity: false,
        }
    }

async getDataFromApi(){
      this.setState({activity: true})
      let usuarios = await GetData();
      console.log(usuarios);
      this.setState({users: usuarios, activity:false})
  }
  /* async getDataFromApi(){
      try{
          const resultado = await AsyncStorage.getItem('key');
          this.setState({users:JSON.parse(resultado)})
      }catch(e){
          console.log(e)
      }
  } */

 
keyExtractor = (item, idx) => idx.toString()

renderItem = ({item})=> {
        return(
            <ScrollView>
                <View>
                    <Personajes
                    nombre={item.results.name}
                    especie={item.results.species}
                    status = {item.results.status} 
                    imagen = {item.results.image}                   
                    />
                </View>
                <TouchableOpacity style={styles.boton}/* onPress={()=> GuardoData("userData", this.state.users)} */>
                    <View>
                        <Text>
                            LIKE
                        </Text>
                    </View>
                </TouchableOpacity>
                <TouchableOpacity>
                    <View>
                        <Text>
                            DISLIKE
                        </Text>
                    </View>
                </TouchableOpacity>
            </ScrollView>

        )
    
    }

separator = ()=> <View style={styles.caja}/>
    render(){
       /*  const values = this.state.users.map(item =>
            <Text key={item.results.id}>
             {item.results.name}
            </Text>
            ) */
        return(
        <ScrollView>
          <View style={styles.cointainer}>
            <View style={styles.caja}>
            <FlatList
            data= {this.state.users}
            keyExtractor={this.keyExtractor}
            renderItem= {this.renderItem}
            ItemSeparatorComponent = {this.separator}
            numColumns= {1}
            />
            <View>
            <TouchableOpacity onPress={()=> Alert.alert("No Funciona")} /* onPress={()=> this.getDataFromApi()} */>
                <View style={styles.caja}>
                    <Text style={styles.texto}>
                        Importar
                    </Text>
                </View>
            </TouchableOpacity>
            </View>
            </View>
          </View>
        </ScrollView> 
    )
  }
}