import AsyncStorage, { useAsyncStorage }from "@react-native-async-storage/async-storage"

export async function GuardoData(key, value){
    try{
        const jsonUsers= JSON.stringify(value)
        await AsyncStorage.setItem(key, jsonUsers)
    }catch(e){
        console.log(e)
    }
}

