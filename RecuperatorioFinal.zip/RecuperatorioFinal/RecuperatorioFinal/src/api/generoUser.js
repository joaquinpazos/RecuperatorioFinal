export async function GetData(){
    try{
        let resultado = await fetch('https://rickandmortyapi.com/api/character/10');
        let json = await resultado.json();
        return json.results;
    }catch(e){
        console.log(e)
    }
}
